# Sistema de Gestão Imobiliária

Trabalho de Avaliação de Proficiência — Paradigma Orientado a Objetos
IFS — Tecnologia em Análise e Desenvolvimento de Sistemas

## Como abrir no IntelliJ

1. Abra o IntelliJ IDEA.
2. **File > Open...** e selecione a pasta `imobiliaria` (a que contém o `pom.xml`).
3. O IntelliJ vai reconhecer o `pom.xml` automaticamente e importar o projeto como Maven
   (pode aparecer um aviso "Maven projects need to be imported" — clique em "Load Maven Project"
   se ele não carregar sozinho).
4. Aguarde o IntelliJ indexar o projeto.

## Como executar

Abra `src/main/java/app/GererenciarAgenda.java` e rode o método `main` (botão ▶ verde ao lado
da classe, ou `Run > Run 'GererenciarAgenda.main()'`).

Alternativamente, pelo terminal:

```
mvn compile exec:java -Dexec.mainClass="app.GererenciarAgenda"
```

## Estrutura de pacotes

- `modelo` — Endereco, Cliente, Imovel (abstrata), Casa, Apartamento, Terreno, enums e Calculavel
- `contrato` — Contrato
- `excecoes` — exceções personalizadas (checked)
- `servico` — ServicoImobiliaria (regras de negócio)
- `app` — GererenciarAgenda (classe com o menu/main)
- `teste` — classe de teste manual (não é JUnit, é só um main auxiliar)

## Observação sobre o nome da classe principal

O nome `GererenciarAgenda` foi mantido conforme consta no enunciado original da avaliação.
