package teste;

import contrato.Contrato;
import modelo.Apartamento;
import modelo.Calculavel;
import modelo.Casa;
import modelo.Cliente;
import modelo.Endereco;
import modelo.StatusImovel;
import modelo.Terreno;
import modelo.TipoTerreno;
import servico.ServicoImobiliaria;


public class TesteParceiro {

    public static void main(String[] args) {
        System.out.println("############################################");
        System.out.println("# TESTE DAS FUNCIONALIDADES DO PARCEIRO(A) #");
        System.out.println("############################################\n");

        testarHierarquiaImovel();
        testarEqualsHashCodeImovel();
        testarVendaEAluguel();
    }

    // -----------------------------------------------------------
    // Teste 1: abstração, herança e polimorfismo (calcularValorFinal)
    // -----------------------------------------------------------
    private static void testarHierarquiaImovel() {
        System.out.println("=== TESTE 1: Hierarquia de Imovel (calcularValorFinal) ===");

        Endereco end1 = new Endereco("Rua das Flores", 100, "Centro", "Aracaju");
        Endereco end2 = new Endereco("Av. Beira Mar", 250, "Atalaia", "Aracaju");
        Endereco end3 = new Endereco("Rodovia dos Náufragos", 1000, "Robalo", "Aracaju");

        Casa casa = new Casa(1, end1, 250000.0, 120.0, 3, true, 3500.0);
        Apartamento apto = new Apartamento(2, end2, 400000.0, 80.0, 5, 502, 600.0, 2200.0);
        Terreno terreno = new Terreno(3, end3, 100000.0, 500.0, TipoTerreno.RESIDENCIAL);

        // Polimorfismo: mesma referência de tipo (Calculavel), comportamento diferente.
        Calculavel[] imoveis = { casa, apto, terreno };

        for (Calculavel c : imoveis) {
            System.out.println(c.getClass().getSimpleName() + " -> valorFinal = "
                    + String.format("%.2f", c.calcularValorFinal()));
        }

        // Conferindo os valores esperados manualmente:
        double esperadoCasa = 250000.0 + 3500.0;                    // valor + iptu
        double esperadoApto = 400000.0 + 2200.0 + 600.0;             // valor + iptu + condominio
        double esperadoTerreno = 100000.0 + (100000.0 * 0.08);       // valor + 8%

        System.out.println("Casa OK? " + (casa.calcularValorFinal() == esperadoCasa));
        System.out.println("Apartamento OK? " + (apto.calcularValorFinal() == esperadoApto));
        System.out.println("Terreno OK? " + (terreno.calcularValorFinal() == esperadoTerreno));

        System.out.println("\ntoString() de cada imovel:");
        System.out.println(casa);
        System.out.println(apto);
        System.out.println(terreno);
        System.out.println();
    }

    // -----------------------------------------------------------
    // Teste 2: equals()/hashCode() de Imovel (igualdade por codigo)
    // -----------------------------------------------------------
    private static void testarEqualsHashCodeImovel() {
        System.out.println("=== TESTE 2: equals()/hashCode() de Imovel (por codigo) ===");

        Endereco end = new Endereco("Rua Teste", 1, "Bairro Teste", "Aracaju");

        Casa casaA = new Casa(10, end, 200000.0, 100.0, 2, false, 1000.0);
        // Mesmo codigo (10), atributos diferentes -> devem ser considerados iguais
        Apartamento aptoMesmoCodigo = new Apartamento(10, end, 999999.0, 999.0, 1, 1, 1.0, 1.0);
        Casa casaCodigoDiferente = new Casa(11, end, 200000.0, 100.0, 2, false, 1000.0);

        System.out.println("casaA.equals(aptoMesmoCodigo) [mesmo cod, esperado TRUE] = "
                + casaA.equals(aptoMesmoCodigo));
        System.out.println("casaA.equals(casaCodigoDiferente) [cod diferente, esperado FALSE] = "
                + casaA.equals(casaCodigoDiferente));
        System.out.println("casaA.hashCode() == aptoMesmoCodigo.hashCode() [esperado TRUE] = "
                + (casaA.hashCode() == aptoMesmoCodigo.hashCode()));
        System.out.println();
    }

    // -----------------------------------------------------------
    // Teste 3: Contrato, venderImovel, alugarImovel e gerarRelatorios
    // -----------------------------------------------------------
    private static void testarVendaEAluguel() {
        System.out.println("=== TESTE 3: venderImovel / alugarImovel / gerarRelatorios ===");

        ServicoImobiliaria servico = new ServicoImobiliaria();

        Endereco end1 = new Endereco("Rua A", 10, "Centro", "Aracaju");
        Endereco end2 = new Endereco("Rua B", 20, "Farolândia", "Aracaju");
        Endereco end3 = new Endereco("Rua C", 30, "Jabotiana", "Aracaju");

        Casa casa = new Casa(1, end1, 250000.0, 120.0, 3, true, 3500.0);
        Apartamento apto = new Apartamento(2, end2, 400000.0, 80.0, 5, 502, 600.0, 2200.0);
        Terreno terreno = new Terreno(3, end3, 100000.0, 500.0, TipoTerreno.COMERCIAL);

        // Inserção direta nas listas do serviço (cadastrarImovel ainda
        // não foi implementado pela Lorena nesta entrega).
        servico.getImoveis().add(casa);
        servico.getImoveis().add(apto);
        servico.getImoveis().add(terreno);

        Cliente comprador = new Cliente("João Silva", "111.111.111-11", "79999990000", "joao@email.com");
        Cliente locatario = new Cliente("Maria Souza", "222.222.222-22", "79999991111", "maria@email.com");

        servico.getClientes().add(comprador);
        servico.getClientes().add(locatario);

        System.out.println("--- Caso de sucesso: vender a Casa (cod 1) ---");
        servico.venderImovel(casa, comprador);
        System.out.println("Status da Casa apos venda: " + casa.getStatus()
                + " [esperado VENDIDO] -> " + (casa.getStatus() == StatusImovel.VENDIDO));

        System.out.println("\n--- Caso de erro: tentar vender a mesma Casa de novo (indisponivel) ---");
        servico.venderImovel(casa, comprador);

        System.out.println("\n--- Caso de sucesso: alugar o Apartamento (cod 2) ---");
        servico.alugarImovel(apto, locatario, 2500.0);
        System.out.println("Status do Apartamento apos aluguel: " + apto.getStatus()
                + " [esperado ALUGADO] -> " + (apto.getStatus() == StatusImovel.ALUGADO));

        System.out.println("\n--- Caso de erro: alugar com valor mensal invalido (<= 0) ---");
        servico.alugarImovel(terreno, locatario, 0.0);
        System.out.println("Status do Terreno apos tentativa invalida: " + terreno.getStatus()
                + " [esperado DISPONIVEL, pois a operacao deve falhar] -> "
                + (terreno.getStatus() == StatusImovel.DISPONIVEL));

        System.out.println("\n--- Caso de sucesso: vender o Terreno (cod 3) ---");
        servico.venderImovel(terreno, comprador);

        System.out.println("\nQuantidade de contratos gerados: " + servico.getContratos().size()
                + " [esperado 3: venda da casa, aluguel do apto, venda do terreno]");
        for (Contrato c : servico.getContratos()) {
            System.out.println("  " + c);
        }

        System.out.println("\n--- Relatorio final ---");
        servico.gerarRelatorios();
    }
}
